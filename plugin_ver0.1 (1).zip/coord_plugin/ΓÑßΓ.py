import openpyxl

print(\u1F503)